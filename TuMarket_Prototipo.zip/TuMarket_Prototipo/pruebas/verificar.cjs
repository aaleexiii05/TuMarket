const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const T=require('../core.js'),D='2026-11-16',results=[];
function test(id,name,fn){try{fn();results.push({id,name,status:'Correcto'})}catch(e){results.push({id,name,status:'Fallo',error:e.message})}}
function fresh(){return T.seed(D)}
function rejectsUnchanged(s,fn){const before=JSON.stringify(s);assert.throws(fn);assert.equal(JSON.stringify(s),before)}
test('F01','Sugerencia de leche: 41 objetivo, 8 vendibles y 33 a comprar',()=>{const x=T.suggestion(fresh(),'P001',D);assert.equal(x.target,41);assert.equal(x.qty,33)});
test('F02','Ajuste de cantidad exige motivo y no altera estado al fallar',()=>{const s=fresh();rejectsUnchanged(s,()=>T.order(s,'P001',36,'','admin',D))});
test('F03','Pedido de 36 descuenta pendientes y evita sugerir compra duplicada',()=>{const s=fresh();T.order(s,'P001',36,'Tres cajas de doce','admin',D);assert.equal(T.pending(s,'P001'),36);assert.equal(T.suggestion(s,'P001',D).qty,0)});
test('F04','Recepción parcial: stock 20 y saldo 24',()=>{const s=fresh(),o=T.order(s,'P001',36,'Tres cajas de doce','admin',D);T.receive(s,o.id,12,'NUEVO','2027-01-31','almacen',D);assert.equal(T.available(T.product(s,'P001'),D),20);assert.equal(T.pending(s,'P001'),24)});
test('F05','Recepción superior al saldo se rechaza',()=>{const s=fresh(),o=T.order(s,'P001',33,'','admin',D);rejectsUnchanged(s,()=>T.receive(s,o.id,34,'NUEVO','2027-01-31','almacen',D))});
test('F06','Recepción vencida se rechaza',()=>{const s=fresh(),o=T.order(s,'P001',33,'','admin',D);rejectsUnchanged(s,()=>T.receive(s,o.id,1,'NUEVO','2026-11-15','admin',D))});
test('F07','Una fecha imposible se rechaza',()=>{const s=fresh(),o=T.order(s,'P001',33,'','admin',D);rejectsUnchanged(s,()=>T.receive(s,o.id,1,'NUEVO','2027-02-30','admin',D))});
test('F08','Venta de 2 leches: S/9, vuelto S/1 y stock 6',()=>{const s=fresh(),r=T.sale(s,[{id:'P001',qty:2}],10,'caja',D);assert.equal(r.total,9);assert.equal(r.change,1);assert.equal(T.available(T.product(s,'P001'),D),6)});
test('F09','Pago insuficiente se rechaza sin descontar stock',()=>{const s=fresh();rejectsUnchanged(s,()=>T.sale(s,[{id:'P001',qty:2}],5,'caja',D))});
test('F10','Venta por encima del stock se rechaza',()=>{const s=fresh();rejectsUnchanged(s,()=>T.sale(s,[{id:'P001',qty:9}],100,'caja',D))});
test('F11','Unidades vencidas no se venden',()=>{const s=fresh();assert.equal(T.physical(T.product(s,'P008')),4);assert.equal(T.available(T.product(s,'P008'),D),0);rejectsUnchanged(s,()=>T.sale(s,[{id:'P008',qty:1}],10,'caja',D))});
test('F12','FEFO descuenta primero el lote apto que vence antes',()=>{const s=fresh(),p=T.product(s,'P001');p.lots.push({id:'CERCA',qty:3,expiry:'2026-11-18'});T.sale(s,[{id:p.id,qty:2}],10,'caja',D);assert.equal(p.lots[0].qty,8);assert.equal(p.lots[1].qty,1)});
test('F13','Baja de 4 panes exige motivo y genera movimiento -4',()=>{const s=fresh();T.adjust(s,'P008','L801',0,'Retiro por vencimiento','almacen',D);assert.equal(T.physical(T.product(s,'P008')),0);assert.equal(s.movements[0].qty,-4)});
test('F14','Conteo negativo y cantidad fraccionaria se rechazan',()=>{const s=fresh();rejectsUnchanged(s,()=>T.adjust(s,'P008','L801',-1,'Prueba de error','admin',D));rejectsUnchanged(s,()=>T.sale(s,[{id:'P001',qty:1.5}],10,'caja',D))});
test('F15','Caja no aprueba pedidos ni cambia parámetros',()=>{const s=fresh();rejectsUnchanged(s,()=>T.order(s,'P001',33,'','caja',D));rejectsUnchanged(s,()=>T.settings(s,'P001',{lead:3,review:4,min:11,safety:6,method:'media'},'caja'))});
test('F16','Cancelación parcial conserva las unidades recibidas',()=>{const s=fresh(),o=T.order(s,'P001',33,'','admin',D);T.receive(s,o.id,12,'NUEVO','2027-01-31','admin',D);T.cancel(s,o.id,'Proveedor no entrega saldo','admin',D);assert.equal(T.pending(s,'P001'),0);assert.equal(T.available(T.product(s,'P001'),D),20)});
test('F17','Pedido completo no admite doble recepción',()=>{const s=fresh(),o=T.order(s,'P001',33,'','admin',D);T.receive(s,o.id,33,'NUEVO','2027-01-31','admin',D);assert.equal(o.status,'recibido');rejectsUnchanged(s,()=>T.receive(s,o.id,1,'OTRO','2027-01-31','admin',D))});
test('F18','Lote existente no acepta otra fecha de vencimiento',()=>{const s=fresh(),o=T.order(s,'P001',33,'','admin',D);rejectsUnchanged(s,()=>T.receive(s,o.id,1,'L101','2027-03-01','admin',D))});
test('F19','Regresión aprende una tendencia conocida y se evalúa fuera del entrenamiento',()=>{const p=T.product(fresh(),'P005');p.history.forEach((h,i)=>h.qty=i+1);const f=T.forecast(p);assert.ok(f.maeModel<1e-9);assert.ok(f.maeBase>0);assert.equal(f.selected,'modelo');assert.ok(f.model>28)});
test('F20','Serie constante: promedio y regresión tienen MAE cero',()=>{const f=T.forecast(T.product(fresh(),'P001'));assert.equal(f.maeBase,0);assert.equal(f.maeModel,0);assert.equal(f.selected,'media')});
test('F21','Seleccionar regresión cambia la sugerencia del jabón a 22',()=>{const s=fresh();T.settings(s,'P005',{lead:2,review:4,safety:3,min:7,method:'modelo'},'admin');assert.equal(T.suggestion(s,'P005',D).qty,22)});
test('F22','Posponer conserva stock y registra motivo',()=>{const s=fresh();T.dismiss(s,'P001','Revisar presupuesto disponible','admin',D);assert.equal(T.available(T.product(s,'P001'),D),8);assert.equal(s.decisions[0].action,'Pospuesta')});
const output={date:D,scope:'Pruebas técnicas automatizadas del motor; datos de ejemplo, sin participantes humanos.',passed:results.filter(r=>r.status==='Correcto').length,total:results.length,results};
fs.writeFileSync(path.join(__dirname,'resultados.json'),JSON.stringify(output,null,2));console.log(JSON.stringify(output,null,2));if(output.passed!==output.total)process.exitCode=1;

# TuMarket — Prototipo de inventario y reposición

## Abrir en menos de un minuto
1. Extrae el ZIP completo.
2. Abre la carpeta TuMarket_Prototipo en VS Code.
3. Abre index.html en un navegador actual. No requiere instalación ni conexión a una API.
4. Recomendado: si ya tienes Live Server, pulsa «Open with Live Server» sobre index.html.

Alternativa con Node instalado: `node servidor.cjs`, luego abre http://localhost:8080.
Usa siempre la misma dirección y navegador para conservar los datos. Si abres con otro puerto, será otro almacenamiento. Trabaja con una sola pestaña.

## Qué incluye
- Resumen: stock bajo, vencimientos y pedidos pendientes.
- Caja: carrito, pago en efectivo, vuelto y descuento de stock por FEFO (primero vence, primero sale).
- Inventario: existencias físicas y vendibles, lotes, vencimientos y conteos con motivo.
- Reposición: cálculo explicable, parámetros, promedio reciente y demostración de regresión lineal.
- Pedidos: aprobación, recepción parcial/completa y cancelación del saldo con motivo.
- Movimientos: ventas, entradas, bajas y decisiones; exportación JSON.

## Recorrido para exponer
1. Restablece el ejemplo. Resumen muestra 8 productos, 3 con stock bajo y 2 lotes por revisar.
2. Reposición → Leche → Ver cálculo. 5 × (3 + 4) + 6 = 41; 41 − 8 − 0 = 33 unidades.
3. Cambia a 36, intenta aprobar sin motivo: debe impedirlo. Escribe «Tres cajas de 12 unidades» y aprueba.
4. Pedidos → Recibir 12 unidades, lote NUEVO y una fecha futura. Quedan 24 pendientes; stock 20.
5. Caja → 2 leches. Total S/9; recibido S/10; vuelto S/1. Stock final de leche 18.
6. Inventario → Pan → Registrar conteo 0 y motivo «Retiro por vencimiento». Se registra baja de 4.
7. Movimientos muestra la recepción, venta, ajuste y aprobación. Recarga la página: se conservan.
8. Reposición → Jabón → Parámetros → Regresión lineal → Actualizar. La estimación de ejemplo cambia a unas 4,32 uds./día y la compra sugerida a 22 unidades.

## IA y límites del alcance
La regresión lineal sí se ajusta mediante mínimos cuadrados a los datos de ejemplo. Se evalúa entrenando con los primeros 21 días y calculando MAE sobre los últimos 7, frente a un promedio de referencia. Después se reajusta con los 28 días para ilustrar la proyección. El promedio permanece como método inicial; el encargado puede seleccionar el otro método.

El historial es ficticio y fijo. Las ventas del día modifican inventario, pero no reentrenan el modelo. Las encuestas no son datos de entrenamiento. Este ejercicio no acredita capacidad predictiva con ventas reales, demanda censurada por falta de stock ni estacionalidad.

La cantidad objetivo es redondeada hacia arriba: demanda × (plazo de entrega + periodo de revisión) + seguridad. Se restan stock vendible y pedidos pendientes. Stock mínimo y cobertura objetivo cumplen funciones distintas. Se permiten ajustes por cajas, presupuesto o criterio comercial con motivo obligatorio; no se automatizan límites monetarios ni vida útil.

Los datos se guardan localmente. No hay servidor empresarial, autenticación segura, sincronización entre equipos, emisión fiscal ni envío de compras a proveedores. El selector de vistas demuestra restricciones de interfaz, no seguridad de producción. No modifiques los archivos JSON exportados para volver a importarlos: no se incluye importador.

## Evidencias y pruebas
- `pruebas/verificar.cjs`: ejecuta `node pruebas/verificar.cjs`. Comprueba 22 casos del motor y genera resultados.json.
- `pruebas/piloto.cjs`: ejecuta `node pruebas/piloto.cjs`. Reproduce el ejercicio operativo de 7 días con el mismo motor, parámetros específicos y demanda ficticia. Genera resultados y CSV.
- `evidencias/`: capturas del prototipo y registros del recorrido técnico. No corresponden a sesiones con trabajadores.
- `procesos/`: diagramas AS IS y TO BE en PNG, SVG y BPMN 2.0 editable. El AS IS es preliminar y requiere contrastar su secuencia con el encargado.

El piloto usa 5 productos, entrega 1 día, revisión 2 días, seguridad 2 unidades y stock mínimo 2 × demanda + 1. Son parámetros diferentes del ejemplo de leche inicial (3 días, 4 días, 6 unidades). El ejercicio excluye vencimientos, costos, retrasos y entregas parciales; esos controles sí existen en el prototipo interactivo.

Para una demostración limpia, usa «Restablecer ejemplo» después de exportar cualquier evidencia que quieras conservar. Los vencimientos se generan relativos al día de inicio. Para ensayar otro día, restablece el ejemplo.

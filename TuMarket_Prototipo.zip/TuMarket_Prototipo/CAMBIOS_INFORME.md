# Ubicación de los cambios en el informe
- Páginas 11–13: tecnología implementada, pronóstico y cálculo de reposición.
- Páginas 14–16: comparación y diagramas AS IS / TO BE.
- Página 21: mapa de empatía.
- Páginas 23–25: pruebas técnicas ejecutadas y ajustes.
- Páginas 26–30: alcance del MVP, validación pendiente y ejercicio operativo simulado.
- Páginas 33–39: arquitectura y capturas del prototipo funcional.
- Páginas 50–51: datos y balance reproducible del ejercicio operativo.

Las pruebas técnicas no acreditan participación de trabajadores. El pronóstico y el ejercicio operativo usan datos de ejemplo. Las fuentes se mantienen de forma breve porque la estructura del docente las solicita.

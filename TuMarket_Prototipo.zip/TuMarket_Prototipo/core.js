/* TuMarket: dominio sin dependencias. Funciona en navegador y Node. */
(function(root){
'use strict';
const day=()=>new Date().toLocaleDateString('en-CA'), iso=d=>d.toISOString().slice(0,10);
const plus=(date,n)=>{let d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return iso(d)};
const integer=(n,label='Cantidad')=>{n=Number(n);if(!Number.isSafeInteger(n)||n<1||n>100000)throw Error(label+': ingresa un entero entre 1 y 100 000.');return n};
const reason=s=>{s=String(s||'').trim();if(s.length<5)throw Error('Explica el motivo con al menos 5 caracteres.');return s.slice(0,300)};
function seed(today=day()){
 const rows=[['P001','Leche evaporada 400 g','Lácteos',4.5,3.4,8,11,3,4,6,5,60],['P002','Arroz extra 1 kg','Abarrotes',4.2,3.1,10,9,2,4,4,4,180],['P003','Galletas de vainilla','Snacks',1.8,1.1,25,7,2,4,3,3,90],['P004','Detergente 500 g','Limpieza',6.9,5,6,5,3,4,2,2,365],['P005','Jabón de tocador','Higiene',3.5,2.4,7,7,2,4,3,3,300],['P006','Yogur natural 1 L','Lácteos',7.5,5.8,10,5,1,2,2,2,4],['P007','Agua mineral 625 ml','Bebidas',1.5,.8,30,13,2,3,6,6,180],['P008','Pan de molde','Panadería',6,4.4,4,5,1,2,2,2,-1]];
 return {version:1,reference:today,products:rows.map((r,i)=>({id:r[0],name:r[1],category:r[2],price:r[3],cost:r[4],min:r[6],lead:r[7],review:r[8],safety:r[9],method:'media',lots:[{id:'L'+(i+1)+'01',qty:r[5],expiry:plus(today,r[11])}],history:Array.from({length:28},(_,j)=>({date:plus(today,j-28),qty:i===0?5:Math.max(0,r[10]+(j%5===0?1:j%5===3?-1:0)+(i===4&&j>15?1:0))}))})),orders:[],sales:[],movements:[],decisions:[],next:1};
}
const product=(s,id)=>{const p=s.products.find(p=>p.id===id);if(!p)throw Error('Producto no encontrado.');return p};
const physical=p=>p.lots.reduce((a,l)=>a+l.qty,0);
const available=(p,today=day())=>p.lots.filter(l=>l.expiry>=today).reduce((a,l)=>a+l.qty,0);
const pending=(s,id)=>s.orders.filter(o=>o.product===id&&o.status==='pendiente').reduce((a,o)=>a+o.qty-o.received,0);
const avg=a=>a.reduce((s,x)=>s+x,0)/a.length;
function fit(a){const n=a.length,x=(n-1)/2,y=avg(a);let den=0,num=0;a.forEach((v,i)=>{den+=(i-x)**2;num+=(i-x)*(v-y)});const slope=den?num/den:0;return {slope,intercept:y-slope*x}}
const pred=(m,x)=>Math.max(0,m.intercept+m.slope*x);
function forecast(p){
 const y=p.history.map(h=>h.qty), train=y.slice(0,-7), test=y.slice(-7), model=fit(train), baseline=avg(train.slice(-7));
 const maeModel=avg(test.map((v,i)=>Math.abs(v-pred(model,train.length+i)))),maeBase=avg(test.map(v=>Math.abs(v-baseline)));
 const full=fit(y), horizon=p.lead+p.review, future=avg(Array.from({length:horizon},(_,i)=>pred(full,y.length+i)));
 return {base:avg(y.slice(-7)),model:future,maeModel,maeBase,selected:maeModel<maeBase?'modelo':'media',history:y};
}
function suggestion(s,id,today=day()) {const p=product(s,id),f=forecast(p),d=p.method==='modelo'?f.model:f.base,stock=available(p,today),open=pending(s,id),target=Math.ceil(d*(p.lead+p.review)+p.safety);return {d,stock,pending:open,target,qty:Math.max(0,target-stock-open),...f}}
function allowed(role,action){const ok={sale:['admin','caja'],order:['admin'],receive:['admin','almacen'],adjust:['admin','almacen'],settings:['admin']};if(!ok[action]?.includes(role))throw Error('Esta acción no está disponible en la vista de trabajo seleccionada.');}
function movement(s,p,type,qty,note,role,ref,today){s.movements.unshift({id:'M'+s.next++,date:today,product:p.id,type,qty,note,role,ref});}
function sale(s,cart,paid,role,today=day()){
 allowed(role,'sale');if(!cart.length)throw Error('Agrega un producto a la venta.');const map=new Map();cart.forEach(x=>{integer(x.qty);map.set(x.id,(map.get(x.id)||0)+Number(x.qty))});
 let cents=0;for(const [id,q]of map){const p=product(s,id);if(q>available(p,today))throw Error('Stock vendible insuficiente: '+p.name);cents+=Math.round(p.price*100)*q;}
 if(!Number.isFinite(Number(paid))||Math.round(Number(paid)*100)<cents)throw Error('El efectivo recibido es menor al total.');
 const id='V'+String(s.next++).padStart(4,'0');for(const [pid,q]of map){const p=product(s,pid);let remain=q;for(const l of [...p.lots].filter(l=>l.expiry>=today).sort((a,b)=>a.expiry.localeCompare(b.expiry))){const n=Math.min(l.qty,remain);l.qty-=n;remain-=n;}movement(s,p,'Venta',-q,'Salida por vencimiento más próximo (FEFO).',role,id,today);}
 const record={id,date:today,items:[...map].map(([id,qty])=>({id,qty,price:product(s,id).price})),total:cents/100,paid:Number(paid),change:(Math.round(Number(paid)*100)-cents)/100};s.sales.unshift(record);return record;
}
function order(s,id,qty,note,role,today=day()) {allowed(role,'order');const p=product(s,id),q=integer(qty),sg=suggestion(s,id,today);if(q!==sg.qty)note=reason(note);const o={id:'OC'+String(s.next++).padStart(4,'0'),date:today,product:p.id,qty:q,received:0,status:'pendiente',note:note||'Se acepta la sugerencia.',snapshot:{d:sg.d,stock:sg.stock,pending:sg.pending,target:sg.target,qty:sg.qty,method:p.method}};s.orders.unshift(o);s.decisions.unshift({date:today,product:id,action:'Aprobada',qty:q,note:o.note,role});return o;}
function dismiss(s,id,note,role,today=day()){allowed(role,'order');product(s,id);note=reason(note);s.decisions.unshift({date:today,product:id,action:'Pospuesta',qty:0,note,role});}
function receive(s,id,qty,lot,expiry,role,today=day()){allowed(role,'receive');const o=s.orders.find(o=>o.id===id);if(!o||o.status!=='pendiente')throw Error('El pedido no tiene saldo pendiente.');const q=integer(qty);if(q>o.qty-o.received)throw Error('La recepción supera el saldo pendiente.');lot=String(lot||'').trim();if(!lot)throw Error('Indica el lote recibido.');if(!/^\d{4}-\d{2}-\d{2}$/.test(expiry)||!Number.isFinite(Date.parse(expiry+'T12:00:00Z'))||iso(new Date(expiry+'T12:00:00Z'))!==expiry||expiry<today)throw Error('Indica una fecha válida, no anterior a hoy.');const p=product(s,o.product),existing=p.lots.find(l=>l.id===lot);if(existing&&existing.expiry!==expiry)throw Error('Ese lote ya tiene otra fecha de vencimiento.');if(existing)existing.qty+=q;else p.lots.push({id:lot,qty:q,expiry});o.received+=q;if(o.received===o.qty)o.status='recibido';movement(s,p,'Recepción',q,'Lote '+lot+' · vence '+expiry,role,id,today);}
function cancel(s,id,note,role,today=day()){allowed(role,'order');const o=s.orders.find(o=>o.id===id);if(!o||o.status!=='pendiente')throw Error('Pedido sin saldo pendiente.');note=reason(note);o.status='cancelado';o.cancelNote=note;s.decisions.unshift({date:today,product:o.product,action:'Saldo cancelado',qty:o.qty-o.received,note,role});}
function adjust(s,id,lotId,count,note,role,today=day()){allowed(role,'adjust');const p=product(s,id),l=p.lots.find(l=>l.id===lotId);if(!l)throw Error('Lote no encontrado.');count=Number(count);if(!Number.isSafeInteger(count)||count<0||count>100000)throw Error('El conteo debe ser un entero entre 0 y 100 000.');note=reason(note);const delta=count-l.qty;if(!delta)throw Error('El conteo coincide con el registro; no requiere ajuste.');l.qty=count;movement(s,p,delta<0?'Baja / ajuste':'Ajuste',delta,'Lote '+lotId+': '+note,role,'CONTEO',today);}
function settings(s,id,values,role){allowed(role,'settings');const p=product(s,id);for(const k of ['lead','review']){integer(values[k]);if(Number(values[k])>30)throw Error('Plazo y revisión deben ser de 1 a 30 días.');}for(const k of ['min','safety'])if(!Number.isSafeInteger(Number(values[k]))||Number(values[k])<0||Number(values[k])>1000)throw Error('Mínimo y seguridad deben estar entre 0 y 1000.');if(!['media','modelo'].includes(values.method))throw Error('Método no válido.');for(const k of ['lead','review','min','safety'])p[k]=Number(values[k]);p.method=values.method;}
const api={day,plus,seed,product,physical,available,pending,forecast,suggestion,sale,order,dismiss,receive,cancel,adjust,settings};root.TM=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
